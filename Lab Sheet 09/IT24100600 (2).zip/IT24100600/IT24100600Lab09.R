setwd("C:\\Users\\hirum\\OneDrive\\Desktop\\IT24100600")
##Exercise
#i
y <- rnorm(25, mean = 45, sd = 2)
print(y)
#ii
t.test(y, mu = 46, alternative = "less")
