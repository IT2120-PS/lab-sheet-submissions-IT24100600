setwd("C:\\Users\\it24100600\\Desktop\\IT24100600")
#Import the dataset (’Exercise.txt’) into R and store it in a data frame called
”branch data”.
branch_data<- read.csv("Exercise.txt", header = TRUE)

#Identify the variable type and scale of measurement for each variable.
head(branch_data)
str(branch_data)

#Obtain boxplot for sales and interpret the shape of the sales distribution
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue",
        border = "black")

#Calculate the five number summary and IQR for advertising variable.
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)

#Write an R function to find the outliers in a numeric vector and check for outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  outliers <- x[x < (Q1 - 1.5*IQR_val) | x > (Q3 + 1.5*IQR_val)]
  return(outliers)
}
#check the outliers in years variables
in years variables.
find_outliers(branch_data$Years)
